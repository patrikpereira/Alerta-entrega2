package br.com.alertaentrega

import android.app.Activity
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.format.DateFormat
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Date
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import org.json.JSONArray

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var source: TextView
    private lateinit var notificationText: TextView
    private lateinit var manualInput: EditText
    private lateinit var evaluation: TextView
    private var receiverRegistered = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { refreshNotification() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(16, 21, 16)
        window.navigationBarColor = android.graphics.Color.rgb(16, 21, 16)
        buildUi()
        refreshAll()
    }

    override fun onResume() {
        super.onResume()
        if (!receiverRegistered) {
            val filter = IntentFilter(ACTION_NEW_RIDE)
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
            else @Suppress("DEPRECATION") registerReceiver(receiver, filter)
            receiverRegistered = true
        }
        refreshAll()
    }

    override fun onPause() {
        if (receiverRegistered) {
            unregisterReceiver(receiver)
            receiverRegistered = false
        }
        super.onPause()
    }

    private fun buildUi() {
        val bg = 0xFF101510.toInt()
        val panel = 0xFF1B241C.toInt()
        val green = 0xFF39D353.toInt()
        val white = 0xFFF3F7F3.toInt()
        val muted = 0xFFB5C1B6.toInt()

        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(28))
        }
        scroll.addView(root)

        root.addView(TextView(this).apply {
            text = "ALERTA ENTREGA"
            textSize = 25f
            setTextColor(green)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "Assistente de atenção para entregadores e motoristas"
            textSize = 14f
            setTextColor(muted)
            setPadding(0, dp(4), 0, dp(18))
        })

        status = cardText(panel, white, 16f, true)
        root.addView(status, marginBottom(12))
        root.addView(makeButton("Ativar acesso às notificações", green, bg) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }, marginBottom(18))
        root.addView(makeButton("Ativar leitura da oferta na tela", green, bg) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }, marginBottom(8))
        root.addView(TextView(this).apply {
            text = "Ative em Acessibilidade. O app tenta ler o texto acessível das ofertas do iFood/99; não faz gestos nem aceita corridas."
            textSize = 12f; setTextColor(muted); setPadding(0, 0, 0, dp(14))
        }, marginBottom(8))

        root.addView(sectionTitle("ÚLTIMA NOTIFICAÇÃO COMPATÍVEL", green), marginBottom(8))
        source = cardText(panel, green, 14f, true)
        root.addView(source, marginBottom(8))
        notificationText = cardText(panel, white, 15f, false)
        root.addView(notificationText, marginBottom(18))

        root.addView(sectionTitle("CONSULTAR ENDEREÇO MANUALMENTE", green), marginBottom(8))
        manualInput = EditText(this).apply {
            hint = "Cole ou digite o endereço"
            setHintTextColor(0xFF89958A.toInt())
            setTextColor(white)
            textSize = 16f
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(panel)
            minLines = 2
            gravity = Gravity.TOP
        }
        root.addView(manualInput, marginBottom(10))
        root.addView(makeButton("Analisar endereço", green, bg) { evaluateManualAddress() }, marginBottom(10))
        evaluation = cardText(panel, white, 15f, false)
        root.addView(evaluation, marginBottom(18))

        root.addView(TextView(this).apply {
            text = "IMPORTANTE\nA leitura da tela exige ativação manual em Acessibilidade. O serviço tenta ler o texto acessível do iFood/99 e não faz gestos nem aceita corridas. Ainda não há base de comunidades conectada; esta versão não confirma se o destino é comunidade."
            textSize = 13f
            setTextColor(muted)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(panel)
        })
        setContentView(scroll)
    }

    private fun refreshAll() {
        val enabled = isNotificationAccessEnabled()
        status.text = if (enabled) "● Acesso às notificações ativado" else "○ Acesso às notificações ainda não ativado"
        refreshNotification()
        if (!::evaluation.isInitialized) return
        if (evaluation.text.isNullOrBlank()) evaluation.text = "Digite um endereço para ver o status da análise."
    }

    private fun refreshNotification() {
        if (!::notificationText.isInitialized) return
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val lastSource = prefs.getString(KEY_LAST_SOURCE, null)
        val lastText = prefs.getString(KEY_LAST_TEXT, null)
        val time = prefs.getLong(KEY_LAST_TIME, 0L)
        if (lastSource == null || lastText.isNullOrBlank()) {
            source.text = "Nenhuma notificação capturada ainda"
            notificationText.text = "Quando chegar uma notificação compatível, o texto disponível aparecerá aqui."
            return
        }
        source.text = "$lastSource • ${DateFormat.format("dd/MM HH:mm", Date(time))}"
        notificationText.text = lastText
        if (looksLikeAddress(lastText)) {
            evaluation.text = "Possível endereço detectado na notificação.\n\nAinda não há dados suficientes para avaliar a segurança deste destino. Confira o endereço completo antes de seguir."
        } else {
            evaluation.text = "A notificação foi recebida, mas não foi possível reconhecer um endereço com confiança. O texto pode não incluir o destino completo."
        }
    }

    private fun evaluateManualAddress() {
        val address = manualInput.text.toString().trim()
        when {
            address.isBlank() -> evaluation.text = "Digite um endereço para iniciar a consulta."
            address.length < 8 -> evaluation.text = "O endereço parece incompleto. Informe rua, número e bairro/cidade, se disponíveis."
            else -> {
                evaluation.text = "Consultando o endereço no OpenStreetMap…\n\nIsso localiza o endereço no mapa, mas não verifica se a região é segura."
                Thread {
                    val result = try {
                        lookupAddress(address)
                    } catch (e: Exception) {
                        "Não foi possível consultar o mapa agora. Verifique a conexão com a internet e tente novamente.\n\nDetalhe: ${e.javaClass.simpleName}"
                    }
                    runOnUiThread { evaluation.text = result }
                }.start()
            }
        }
    }

    private fun lookupAddress(address: String): String {
        val encoded = URLEncoder.encode(address, "UTF-8")
        val url = URL("https://nominatim.openstreetmap.org/search?q=$encoded&format=jsonv2&limit=1&addressdetails=1")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 12000
            readTimeout = 12000
            setRequestProperty("User-Agent", "AlertaEntrega/0.2 (Android address lookup)")
            setRequestProperty("Accept-Language", "pt-BR,pt,en")
        }
        try {
            if (connection.responseCode != HttpURLConnection.HTTP_OK) {
                return "O serviço de mapas não respondeu como esperado (HTTP ${connection.responseCode}). Tente novamente mais tarde."
            }
            val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val results = JSONArray(body)
            if (results.length() == 0) {
                return "ENDEREÇO INFORMADO\n$address\n\nNão encontramos uma correspondência no mapa. Tente acrescentar bairro, cidade e estado."
            }
            val item = results.getJSONObject(0)
            val displayName = item.optString("display_name", address)
            val lat = item.optString("lat", "")
            val lon = item.optString("lon", "")
            return "ENDEREÇO LOCALIZADO NO MAPA\n$displayName\n\nCoordenadas: $lat, $lon\nFonte: OpenStreetMap / Nominatim\n\nIMPORTANTE: isso apenas confirma uma correspondência geográfica aproximada. Ainda não há uma base de ocorrências ou relatos verificados conectada; portanto, não é possível concluir se o destino é seguro ou perigoso. Confirme o local no mapa antes de seguir."
        } finally {
            connection.disconnect()
        }
    }

    private fun looksLikeAddress(text: String): Boolean {
        val t = text.lowercase()
        val hints = listOf("rua ", "avenida ", "av. ", "estrada ", "travessa ", "alameda ", "bairro ", "cep", "entregar em", "endereço")
        return hints.any { t.contains(it) } || Regex("\\b\\d{5}-?\\d{3}\\b").containsMatchIn(t)
    }

    private fun isNotificationAccessEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return enabled.contains(packageName)
    }

    private fun sectionTitle(text: String, color: Int) = TextView(this).apply {
        this.text = text
        textSize = 12f
        setTextColor(color)
        typeface = android.graphics.Typeface.DEFAULT_BOLD
    }

    private fun cardText(background: Int, foreground: Int, size: Float, bold: Boolean) = TextView(this).apply {
        textSize = size
        setTextColor(foreground)
        setPadding(dp(14), dp(14), dp(14), dp(14))
        setBackgroundColor(background)
        if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD
        minHeight = dp(48)
    }

    private fun makeButton(label: String, color: Int, textColor: Int, action: () -> Unit) = Button(this).apply {
        text = label
        setTextColor(textColor)
        setBackgroundColor(color)
        textSize = 14f
        setOnClickListener { action() }
        isAllCaps = false
    }

    private fun marginBottom(bottom: Int) = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
        bottomMargin = bottom
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        const val PREFS = "alerta_entrega_prefs"
        const val KEY_LAST_SOURCE = "last_source"
        const val KEY_LAST_TEXT = "last_text"
        const val KEY_LAST_TIME = "last_time"
        const val ACTION_NEW_RIDE = "br.com.alertaentrega.NEW_RIDE_NOTIFICATION"
    }
}
