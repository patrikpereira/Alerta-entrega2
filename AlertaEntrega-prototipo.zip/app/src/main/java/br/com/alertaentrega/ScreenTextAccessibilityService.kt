package br.com.alertaentrega

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Opt-in reader for visible accessible text in iFood/99. Never interacts with offers. */
class ScreenTextAccessibilityService : AccessibilityService() {
    private var lastSaved = ""
    private var lastSavedAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString()?.lowercase().orEmpty()
        val source = when {
            pkg.contains("ifood") -> "iFood"
            pkg.contains("99") || pkg.contains("taxi") -> "99"
            else -> return
        }
        val root = rootInActiveWindow ?: return
        val found = StringBuilder()
        collectText(root, found, 0)
        val text = found.toString().lines().map { it.trim() }.filter { it.isNotBlank() }.distinct().joinToString("\n")
        if (text.isBlank() || !looksLikeAddress(text)) return
        val now = System.currentTimeMillis()
        if (text == lastSaved && now - lastSavedAt < 8000) return
        lastSaved = text; lastSavedAt = now
        getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit()
            .putString(MainActivity.KEY_LAST_SOURCE, "$source • texto da tela")
            .putString(MainActivity.KEY_LAST_TEXT, text.take(1800))
            .putLong(MainActivity.KEY_LAST_TIME, now).apply()
        sendBroadcast(Intent(MainActivity.ACTION_NEW_RIDE).setPackage(packageName))
    }

    private fun collectText(node: AccessibilityNodeInfo?, out: StringBuilder, depth: Int) {
        if (node == null || depth > 30 || out.length > 6000) return
        node.text?.toString()?.takeIf { it.isNotBlank() }?.let { out.append(it).append('\n') }
        node.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { out.append(it).append('\n') }
        for (i in 0 until node.childCount) collectText(node.getChild(i), out, depth + 1)
    }
    private fun looksLikeAddress(text: String): Boolean {
        val t = text.lowercase()
        val hints = listOf("rua ", "r. ", "avenida ", "av. ", "estrada ", "travessa ", "alameda ", "bairro ", "cep", "entrega", "entregar em")
        return hints.any { t.contains(it) } || Regex("\\b\\d{5}-?\\d{3}\\b").containsMatchIn(t)
    }
    override fun onInterrupt() {}
}
