package br.com.alertaentrega

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Captures notifications only after the user explicitly grants Android notification access. */
class RideNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        val combined = listOf(title, text, bigText).filter { it.isNotBlank() }.distinct().joinToString("\n")
        if (combined.isBlank()) return

        val pkg = sbn.packageName.lowercase()
        val source = when {
            pkg.contains("ifood") -> "iFood"
            pkg.contains("99") || pkg.contains("taxi") -> "99"
            else -> return // Ignore unrelated notifications; do not store their content.
        }

        val prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
        prefs.edit()
            .putString(MainActivity.KEY_LAST_SOURCE, source)
            .putString(MainActivity.KEY_LAST_TEXT, combined.take(1800))
            .putLong(MainActivity.KEY_LAST_TIME, System.currentTimeMillis())
            .apply()

        sendBroadcast(android.content.Intent(MainActivity.ACTION_NEW_RIDE))
    }
}
