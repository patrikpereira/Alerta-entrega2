# Alerta Entrega — protótipo Android 0.1.0

Primeiro protótipo nativo em Kotlin para Android. A interface usa preto e verde, permite inserir endereço manualmente e captura notificações do iFood/99 quando o usuário concede acesso especial às notificações do Android.

## O que funciona nesta versão
- Tela inicial em português.
- Atalho para as configurações de acesso às notificações.
- Captura local do texto disponível em notificações dos aplicativos cujo nome de pacote contém `ifood`, `99` ou `taxi`.
- Exibição da última notificação capturada.
- Heurística simples para sinalizar que o texto pode conter endereço.
- Consulta manual que devolve “Informações insuficientes”, sem inventar uma classificação de risco.

## Limitações importantes
- Não há base de dados de risco, mapa ou relatos colaborativos ainda.
- As plataformas podem omitir o endereço das notificações ou mudar o formato do texto.
- A classificação automática não afirma que uma região é segura ou perigosa.
- O texto da notificação é salvo localmente no aparelho; trate esses dados como potencialmente sensíveis. Antes de distribuição pública, implementar controles de retenção, exclusão e privacidade.
- A detecção por notificações precisa ser testada em aparelhos reais com versões instaladas do iFood e da 99. A lista de pacotes pode precisar de ajuste.

## Abrir e compilar
1. Instale o Android Studio atual com Android SDK Platform 35 e JDK 17 ou compatível.
2. Abra a pasta `AlertaEntrega` no Android Studio e aguarde a sincronização Gradle.
3. Se solicitado, aceite a instalação do Gradle e dos componentes do SDK.
4. Use **Build > Build APK(s)**.
5. O APK de debug normalmente será criado em `app/build/outputs/apk/debug/app-debug.apk`.
6. Instale no Android e abra **Ativar acesso às notificações**. Ative o acesso para o Alerta Entrega.
7. Com o iFood/99 instalado, teste com notificações reais e confirme quais campos aparecem.

## Próximas etapas
1. Testar a leitura de notificações nos dois aplicativos.
2. Melhorar a extração de endereço e adicionar modo manual de correção.
3. Definir fontes confiáveis de informação geográfica e relatos com data, confiança e moderação.
4. Criar mapa de consulta e histórico com controles de privacidade.
